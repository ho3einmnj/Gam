/**
 * Classical Guitar Nylon String Sound Engine
 * Synthesizes acoustic nylon guitar tone using Web Audio API
 */
class GuitarSoundEngine {
  constructor() {
    this.ctx = null;
    this.masterGain = null;
    this.isMuted = false;
  }

  init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
        this.masterGain = this.ctx.createGain();
        this.masterGain.gain.setValueAtTime(0.7, this.ctx.currentTime);
        this.masterGain.connect(this.ctx.destination);
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  setMuted(muted) {
    this.isMuted = muted;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(muted ? 0 : 0.7, this.ctx.currentTime);
    }
  }

  /**
   * Play a single classical guitar note with given frequency (Hz)
   * Uses warm additive synthesis with nylon string harmonic decay & body filtering
   */
  playNote(frequency, duration = 1.8, velocity = 0.8) {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;

    // Body resonance filter simulating classical guitar Spanish cedar / spruce top
    const bodyFilter = this.ctx.createBiquadFilter();
    bodyFilter.type = 'lowpass';
    // Nylon strings have warm top-end rolloff around 1800 - 3200 Hz
    bodyFilter.frequency.setValueAtTime(Math.min(3200, frequency * 4.5), now);
    bodyFilter.frequency.exponentialRampToValueAtTime(Math.max(400, frequency * 1.5), now + duration);

    const voiceGain = this.ctx.createGain();
    voiceGain.gain.setValueAtTime(0.001, now);
    // Pluck attack
    voiceGain.gain.linearRampToValueAtTime(velocity * 0.45, now + 0.008);
    // Initial string pluck decay
    voiceGain.gain.exponentialRampToValueAtTime(velocity * 0.22, now + 0.12);
    // Ringing sustain to silence
    voiceGain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

    voiceGain.connect(bodyFilter);
    bodyFilter.connect(this.masterGain);

    // Fundamental oscillator (triangle wave gives rich wood acoustic warmth)
    const osc1 = this.ctx.createOscillator();
    osc1.type = 'triangle';
    osc1.frequency.setValueAtTime(frequency, now);

    // Subtle 2nd harmonic (octave warmth)
    const osc2 = this.ctx.createOscillator();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(frequency * 2, now);
    const osc2Gain = this.ctx.createGain();
    osc2Gain.gain.setValueAtTime(0.35, now);
    osc2Gain.gain.exponentialRampToValueAtTime(0.01, now + (duration * 0.6));
    osc2.connect(osc2Gain);
    osc2Gain.connect(voiceGain);

    // Subtle 3rd harmonic (nylon string bite)
    const osc3 = this.ctx.createOscillator();
    osc3.type = 'sine';
    osc3.frequency.setValueAtTime(frequency * 3, now);
    const osc3Gain = this.ctx.createGain();
    osc3Gain.gain.setValueAtTime(0.18, now);
    osc3Gain.gain.exponentialRampToValueAtTime(0.005, now + (duration * 0.4));
    osc3.connect(osc3Gain);
    osc3Gain.connect(voiceGain);

    // Percussive fingertip / nail transient noise (plucking attack)
    const bufferSize = this.ctx.sampleRate * 0.025;
    const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufferSize * 0.25));
    }
    const noiseNode = this.ctx.createBufferSource();
    noiseNode.buffer = noiseBuffer;
    const noiseGain = this.ctx.createGain();
    noiseGain.gain.setValueAtTime(velocity * 0.18, now);
    noiseGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.025);
    noiseNode.connect(noiseGain);
    noiseGain.connect(voiceGain);

    osc1.connect(voiceGain);

    osc1.start(now);
    osc2.start(now);
    osc3.start(now);
    noiseNode.start(now);

    osc1.stop(now + duration);
    osc2.stop(now + duration);
    osc3.stop(now + duration);
    noiseNode.stop(now + 0.03);
  }

  /**
   * Strum a triad or chord with slight arpeggiated delay between strings (35ms)
   */
  strumChord(notes, isSlow = false) {
    this.init();
    const delayStep = isSlow ? 0.09 : 0.035;
    notes.forEach((n, idx) => {
      setTimeout(() => {
        this.playNote(n.frequency, 2.2, 0.75 - (idx * 0.03));
      }, idx * delayStep * 1000);
    });
  }

  /**
   * Play scale notes in ascending sequence
   */
  playScale(notes, tempoBpm = 110, onStep = null, onFinish = null) {
    this.init();
    const stepDuration = 60 / tempoBpm;
    notes.forEach((note, idx) => {
      setTimeout(() => {
        this.playNote(note.frequency, 1.2, 0.8);
        if (onStep) onStep(idx, note);
        if (idx === notes.length - 1 && onFinish) {
          setTimeout(onFinish, stepDuration * 1000);
        }
      }, idx * stepDuration * 1000);
    });
  }
}

const guitarSound = new GuitarSoundEngine();
