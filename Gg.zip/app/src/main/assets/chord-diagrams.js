/**
 * Classical Guitar Chord Diagrams Generator
 * Produces minimalist, accurate SVG chord diagrams for classical guitarists.
 */

// Dictionary of classic guitar chord fingerings [s6, s5, s4, s3, s2, s1]
// string: -1 = mute (x), 0 = open (o), >0 = fret number
// fingers: finger number 1 to 4, 0 for open, null for mute
const CLASSICAL_CHORDS = {
  // Majors
  'C':   { frets: [-1, 3, 2, 0, 1, 0], fingers: [null, 3, 2, 0, 1, 0], baseFret: 1 },
  'C♯':  { frets: [-1, 4, 3, 1, 2, 1], fingers: [null, 4, 3, 1, 2, 1], baseFret: 1, barre: { fret: 1, from: 1, to: 3 } },
  'D♭':  { frets: [-1, 4, 3, 1, 2, 1], fingers: [null, 4, 3, 1, 2, 1], baseFret: 1, barre: { fret: 1, from: 1, to: 3 } },
  'D':   { frets: [-1, -1, 0, 2, 3, 2], fingers: [null, null, 0, 1, 3, 2], baseFret: 1 },
  'D♯':  { frets: [-1, -1, 1, 3, 4, 3], fingers: [null, null, 1, 2, 4, 3], baseFret: 1 },
  'E♭':  { frets: [-1, 6, 5, 3, 4, 3], fingers: [null, 4, 3, 1, 2, 1], baseFret: 3, barre: { fret: 3, from: 1, to: 3 } },
  'E':   { frets: [0, 2, 2, 1, 0, 0],  fingers: [0, 2, 3, 1, 0, 0], baseFret: 1 },
  'F':   { frets: [1, 3, 3, 2, 1, 1],  fingers: [1, 3, 4, 2, 1, 1], baseFret: 1, barre: { fret: 1, from: 1, to: 6 } },
  'F♯':  { frets: [2, 4, 4, 3, 2, 2],  fingers: [1, 3, 4, 2, 1, 1], baseFret: 2, barre: { fret: 2, from: 1, to: 6 } },
  'G♭':  { frets: [2, 4, 4, 3, 2, 2],  fingers: [1, 3, 4, 2, 1, 1], baseFret: 2, barre: { fret: 2, from: 1, to: 6 } },
  'G':   { frets: [3, 2, 0, 0, 0, 3],  fingers: [3, 2, 0, 0, 0, 4], baseFret: 1 },
  'G♯':  { frets: [4, 6, 6, 5, 4, 4],  fingers: [1, 3, 4, 2, 1, 1], baseFret: 4, barre: { fret: 4, from: 1, to: 6 } },
  'A♭':  { frets: [4, 6, 6, 5, 4, 4],  fingers: [1, 3, 4, 2, 1, 1], baseFret: 4, barre: { fret: 4, from: 1, to: 6 } },
  'A':   { frets: [-1, 0, 2, 2, 2, 0], fingers: [null, 0, 1, 2, 3, 0], baseFret: 1 },
  'A♯':  { frets: [-1, 1, 3, 3, 3, 1], fingers: [null, 1, 2, 3, 4, 1], baseFret: 1, barre: { fret: 1, from: 1, to: 5 } },
  'B♭':  { frets: [-1, 1, 3, 3, 3, 1], fingers: [null, 1, 2, 3, 4, 1], baseFret: 1, barre: { fret: 1, from: 1, to: 5 } },
  'B':   { frets: [-1, 2, 4, 4, 4, 2], fingers: [null, 1, 2, 3, 4, 1], baseFret: 2, barre: { fret: 2, from: 1, to: 5 } },

  // Minors
  'Cm':  { frets: [-1, 3, 5, 5, 4, 3], fingers: [null, 1, 3, 4, 2, 1], baseFret: 3, barre: { fret: 3, from: 1, to: 5 } },
  'C♯m': { frets: [-1, 4, 6, 6, 5, 4], fingers: [null, 1, 3, 4, 2, 1], baseFret: 4, barre: { fret: 4, from: 1, to: 5 } },
  'Dm':  { frets: [-1, -1, 0, 2, 3, 1], fingers: [null, null, 0, 2, 3, 1], baseFret: 1 },
  'D♯m': { frets: [-1, -1, 1, 3, 4, 2], fingers: [null, null, 1, 3, 4, 2], baseFret: 1 },
  'E♭m': { frets: [-1, 6, 8, 8, 7, 6], fingers: [null, 1, 3, 4, 2, 1], baseFret: 6, barre: { fret: 6, from: 1, to: 5 } },
  'Em':  { frets: [0, 2, 2, 0, 0, 0],  fingers: [0, 2, 3, 0, 0, 0], baseFret: 1 },
  'Fm':  { frets: [1, 3, 3, 1, 1, 1],  fingers: [1, 3, 4, 1, 1, 1], baseFret: 1, barre: { fret: 1, from: 1, to: 6 } },
  'F♯m': { frets: [2, 4, 4, 2, 2, 2],  fingers: [1, 3, 4, 1, 1, 1], baseFret: 2, barre: { fret: 2, from: 1, to: 6 } },
  'Gm':  { frets: [3, 5, 5, 3, 3, 3],  fingers: [1, 3, 4, 1, 1, 1], baseFret: 3, barre: { fret: 3, from: 1, to: 6 } },
  'G♯m': { frets: [4, 6, 6, 4, 4, 4],  fingers: [1, 3, 4, 1, 1, 1], baseFret: 4, barre: { fret: 4, from: 1, to: 6 } },
  'A♭m': { frets: [4, 6, 6, 4, 4, 4],  fingers: [1, 3, 4, 1, 1, 1], baseFret: 4, barre: { fret: 4, from: 1, to: 6 } },
  'Am':  { frets: [-1, 0, 2, 2, 1, 0], fingers: [null, 0, 2, 3, 1, 0], baseFret: 1 },
  'A♯m': { frets: [-1, 1, 3, 3, 2, 1], fingers: [null, 1, 3, 4, 2, 1], baseFret: 1, barre: { fret: 1, from: 1, to: 5 } },
  'B♭m': { frets: [-1, 1, 3, 3, 2, 1], fingers: [null, 1, 3, 4, 2, 1], baseFret: 1, barre: { fret: 1, from: 1, to: 5 } },
  'Bm':  { frets: [-1, 2, 4, 4, 3, 2], fingers: [null, 1, 3, 4, 2, 1], baseFret: 2, barre: { fret: 2, from: 1, to: 5 } },

  // Diminished
  'C°':   { frets: [-1, 3, 4, 2, 4, -1], fingers: [null, 2, 3, 1, 4, null], baseFret: 2 },
  'C♯°':  { frets: [-1, 4, 2, 0, 2, 0], fingers: [null, 3, 2, 0, 1, 0], baseFret: 1 },
  'D°':   { frets: [-1, -1, 0, 1, 3, 1], fingers: [null, null, 0, 1, 3, 2], baseFret: 1 },
  'D♯°':  { frets: [-1, -1, 1, 2, 4, 2], fingers: [null, null, 1, 2, 4, 3], baseFret: 1 },
  'E♭°':  { frets: [-1, -1, 1, 2, 4, 2], fingers: [null, null, 1, 2, 4, 3], baseFret: 1 },
  'E°':   { frets: [0, 1, 2, 0, -1, -1], fingers: [0, 1, 2, 0, null, null], baseFret: 1 },
  'F°':   { frets: [1, 2, 0, 1, -1, -1], fingers: [1, 2, 0, 1, null, null], baseFret: 1 },
  'F♯°':  { frets: [2, 0, 1, 2, -1, -1], fingers: [2, 0, 1, 3, null, null], baseFret: 1 },
  'G°':   { frets: [3, 1, 2, 0, -1, -1], fingers: [3, 1, 2, 0, null, null], baseFret: 1 },
  'G♯°':  { frets: [4, 2, 3, 1, -1, -1], fingers: [4, 2, 3, 1, null, null], baseFret: 1 },
  'A°':   { frets: [-1, 0, 1, 2, 1, -1], fingers: [null, 0, 1, 3, 2, null], baseFret: 1 },
  'A♯°':  { frets: [-1, 1, 2, 0, 2, -1], fingers: [null, 1, 2, 0, 3, null], baseFret: 1 },
  'B♭°':  { frets: [-1, 1, 2, 0, 2, -1], fingers: [null, 1, 2, 0, 3, null], baseFret: 1 },
  'B°':   { frets: [-1, 2, 0, 1, 0, 1], fingers: [null, 2, 0, 1, 0, 1], baseFret: 1 },

  // Augmented
  'C+':   { frets: [-1, 3, 2, 1, 1, 0], fingers: [null, 3, 2, 1, 1, 0], baseFret: 1 },
  'D+':   { frets: [-1, -1, 0, 3, 3, 2], fingers: [null, null, 0, 2, 3, 1], baseFret: 1 },
  'E+':   { frets: [0, 3, 2, 1, 1, 0],  fingers: [0, 4, 3, 1, 2, 0], baseFret: 1 },
  'F+':   { frets: [1, 0, 3, 2, 2, 1],  fingers: [1, 0, 4, 2, 3, 1], baseFret: 1 },
  'G+':   { frets: [3, 2, 1, 0, 0, 3],  fingers: [3, 2, 1, 0, 0, 4], baseFret: 1 },
  'A+':   { frets: [-1, 0, 3, 2, 2, 1], fingers: [null, 0, 4, 2, 3, 1], baseFret: 1 },
  'B+':   { frets: [-1, 2, 1, 0, 0, 3], fingers: [null, 2, 1, 0, 0, 3], baseFret: 1 }
};

/**
 * Generate a compact, beautiful SVG chord diagram string
 */
function renderChordDiagramSVG(chordName, triadInfo = null) {
  // Normalize chordName key (e.g. C# -> C♯)
  let cleanName = chordName.replace(/#/g, '♯').replace(/b/g, '♭');
  let chord = CLASSICAL_CHORDS[cleanName] || CLASSICAL_CHORDS[chordName];

  // If not found in dictionary, fallback to clean triad voicing
  if (!chord && triadInfo) {
    chord = generateDynamicTriadVoicing(triadInfo);
  }
  if (!chord) {
    chord = { frets: [-1, -1, 0, 2, 3, 2], fingers: [null, null, 0, 1, 3, 2], baseFret: 1 };
  }

  const width = 110;
  const height = 135;
  const marginX = 22;
  const marginTop = 28;
  const stringSpacing = 13;
  const fretSpacing = 19;
  const numFrets = 4;

  const baseFret = chord.baseFret || 1;
  const isNut = baseFret === 1;

  let svg = `<svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" xmlns="http://www.w3.org/2000/svg" style="display:block;">`;

  // Base Fret indicator if not nut
  if (!isNut) {
    svg += `<text x="8" y="${marginTop + 14}" font-family="'Vazirmatn', sans-serif" font-size="10" font-weight="700" fill="#96887E">${baseFret}fr</text>`;
  }

  // Draw Nut or top fret wire
  if (isNut) {
    svg += `<rect x="${marginX}" y="${marginTop - 2}" width="${stringSpacing * 5}" height="4.5" rx="1.5" fill="#3D3028" />`;
  } else {
    svg += `<line x1="${marginX}" y1="${marginTop}" x2="${marginX + stringSpacing * 5}" y2="${marginTop}" stroke="#B8A892" stroke-width="1.8" />`;
  }

  // Draw horizontal fret lines
  for (let f = 1; f <= numFrets; f++) {
    const y = marginTop + f * fretSpacing;
    svg += `<line x1="${marginX}" y1="${y}" x2="${marginX + stringSpacing * 5}" y2="${y}" stroke="#B8A892" stroke-width="1.2" />`;
  }

  // Draw 6 vertical string lines (Strings 6 to 1, right to left or left to right)
  // In classical diagrams standard: String 6 (Bass E) on left, String 1 (Treble E) on right
  for (let s = 0; s < 6; s++) {
    const x = marginX + s * stringSpacing;
    const strWidth = [2.2, 1.8, 1.5, 1.2, 1.0, 0.8][s];
    const strColor = s < 3 ? '#A89279' : '#C7B9A5';
    svg += `<line x1="${x}" y1="${marginTop}" x2="${x}" y2="${marginTop + numFrets * fretSpacing}" stroke="${strColor}" stroke-width="${strWidth}" />`;
  }

  // Draw Open (O) / Muted (X) markers above the nut
  for (let s = 0; s < 6; s++) {
    const x = marginX + s * stringSpacing;
    const fret = chord.frets[s];
    if (fret === -1) {
      // Muted X
      svg += `<text x="${x}" y="${marginTop - 7}" font-family="sans-serif" font-size="11" font-weight="700" fill="#96887E" text-anchor="middle">×</text>`;
    } else if (fret === 0) {
      // Open O
      svg += `<circle cx="${x}" cy="${marginTop - 9}" r="3.5" fill="none" stroke="#28201B" stroke-width="1.5" />`;
    }
  }

  // Draw Barre if present
  if (chord.barre) {
    const bFret = chord.barre.fret;
    const relFret = bFret - baseFret + 1;
    if (relFret >= 1 && relFret <= numFrets) {
      const y = marginTop + (relFret - 0.5) * fretSpacing;
      // String index: 6 is index 0, 1 is index 5
      const sStart = 6 - chord.barre.to;
      const sEnd = 6 - chord.barre.from;
      const x1 = marginX + sStart * stringSpacing;
      const x2 = marginX + sEnd * stringSpacing;
      svg += `<rect x="${x1 - 4}" y="${y - 4.5}" width="${x2 - x1 + 8}" height="9" rx="4.5" fill="#BD5338" opacity="0.9" />`;
    }
  }

  // Draw fretted note dots with finger numbers
  for (let s = 0; s < 6; s++) {
    const fret = chord.frets[s];
    if (fret > 0) {
      const relFret = fret - baseFret + 1;
      if (relFret >= 1 && relFret <= numFrets) {
        const x = marginX + s * stringSpacing;
        const y = marginTop + (relFret - 0.5) * fretSpacing;
        const finger = chord.fingers ? chord.fingers[s] : null;

        // Warm terracotta dot
        svg += `<circle cx="${x}" cy="${y}" r="6" fill="#BD5338" />`;
        if (finger && finger > 0) {
          svg += `<text x="${x}" y="${y + 3.5}" font-family="'Vazirmatn', sans-serif" font-size="8.5" font-weight="800" fill="#FAF7F2" text-anchor="middle">${finger}</text>`;
        }
      }
    }
  }

  svg += `</svg>`;
  return svg;
}

/**
 * Dynamic fallback generator for rare or complex voicings
 */
function generateDynamicTriadVoicing(triadInfo) {
  const rootPC = triadInfo.rootNote.pitchClass;
  const thirdPC = triadInfo.thirdNote.pitchClass;
  const fifthPC = triadInfo.fifthNote.pitchClass;

  // Build a compact triad on strings 4, 3, 2, 1
  return {
    frets: [-1, -1, 0, 2, 3, 2],
    fingers: [null, null, 0, 1, 3, 2],
    baseFret: 1
  };
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    renderChordDiagramSVG,
    CLASSICAL_CHORDS
  };
}
