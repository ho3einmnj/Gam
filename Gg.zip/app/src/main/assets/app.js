/**
 * Classical Guitar Theory Application Controller
 * Handles UI interactions, VexFlow stave rendering, audio playback, and quiz practice.
 */

document.addEventListener('DOMContentLoaded', () => {
  // Global State
  const state = {
    currentTab: 'tab-notes',
    soundMuted: false,
    selectedNote: {
      stringNumber: 5,
      fretNumber: 3 // C4 (Middle C)
    },
    selectedRoot: 'C',
    selectedScale: 'major',
    isPlayingScale: false,
    quizActive: false,
    quizTarget: null,
    quizScore: 0
  };

  // DOM Elements
  const tabButtons = document.querySelectorAll('.nav-item');
  const tabScreens = document.querySelectorAll('.tab-screen');
  const muteBtn = document.getElementById('btn-mute');
  const muteIcon = document.getElementById('mute-icon');

  // Tab 1 Elements
  const singleStaveContainer = document.getElementById('single-stave-container');
  const spotlightLetter = document.getElementById('spotlight-letter');
  const spotlightTitle = document.getElementById('spotlight-title');
  const spotlightPersian = document.getElementById('spotlight-persian');
  const spotlightFret = document.getElementById('spotlight-fret');
  const spotlightFreq = document.getElementById('spotlight-freq');
  const nutFretboardView = document.getElementById('nut-fretboard-view');
  const quizToggleBtn = document.getElementById('btn-quiz-toggle');
  const quizPanel = document.getElementById('quiz-panel');
  const quizInstruction = document.getElementById('quiz-instruction');
  const quizFeedback = document.getElementById('quiz-feedback');
  const quizScoreEl = document.getElementById('quiz-score');

  // Tab 2 Elements
  const scaleRootSelect = document.getElementById('scale-root-select');
  const scaleTypeSelect = document.getElementById('scale-type-select');
  const scaleChipsRow = document.getElementById('scale-chips-row');
  const scaleFormulaBadge = document.getElementById('scale-formula-badge');
  const scaleStaveContainer = document.getElementById('scale-stave-container');
  const fullFretboardView = document.getElementById('full-fretboard-view');
  const playScaleBtn = document.getElementById('btn-play-scale');
  const scaleDescEl = document.getElementById('scale-description');

  // Tab 3 Elements
  const chordRootSelect = document.getElementById('chord-root-select');
  const chordScaleSelect = document.getElementById('chord-scale-select');
  const triadsContainer = document.getElementById('triads-container');
  const nonDiatonicNotice = document.getElementById('non-diatonic-notice');

  // --- AUDIO INITIALIZATION ---
  function ensureAudioUnlocked() {
    guitarSound.init();
  }
  document.body.addEventListener('click', ensureAudioUnlocked, { once: true });
  document.body.addEventListener('touchstart', ensureAudioUnlocked, { once: true });

  // Mute Toggle
  if (muteBtn) {
    muteBtn.addEventListener('click', () => {
      state.soundMuted = !state.soundMuted;
      guitarSound.setMuted(state.soundMuted);
      if (state.soundMuted) {
        muteIcon.innerHTML = `
          <path fill="currentColor" d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"/>
        `;
        muteBtn.classList.add('muted');
      } else {
        muteIcon.innerHTML = `
          <path fill="currentColor" d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/>
        `;
        muteBtn.classList.remove('muted');
      }
    });
  }

  // --- TAB NAVIGATION ---
  tabButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetTab = btn.getAttribute('data-tab');
      switchTab(targetTab);
    });
  });

  function switchTab(tabId) {
    state.currentTab = tabId;
    tabButtons.forEach(btn => {
      const isActive = btn.getAttribute('data-tab') === tabId;
      btn.classList.toggle('active', isActive);
    });

    tabScreens.forEach(screen => {
      const isTarget = screen.id === tabId;
      if (isTarget) {
        screen.style.display = 'flex';
        // Trigger reflow for transition
        void screen.offsetWidth;
        screen.classList.add('active');
      } else {
        screen.classList.remove('active');
        screen.style.display = 'none';
      }
    });

    // Refresh rendering on tab switch
    if (tabId === 'tab-notes') {
      renderTab1();
    } else if (tabId === 'tab-scales') {
      renderTab2();
    } else if (tabId === 'tab-chords') {
      renderTab3();
    }
  }

  // --- POPULATE DROPDOWNS ---
  function populateSelects() {
    ROOT_NOTES.forEach(root => {
      const opt1 = new Option(`${root.name} - ${root.persian}`, root.id);
      const opt2 = new Option(`${root.name} - ${root.persian}`, root.id);
      if (scaleRootSelect) scaleRootSelect.add(opt1);
      if (chordRootSelect) chordRootSelect.add(opt2);
    });

    Object.values(SCALES).forEach(scale => {
      const opt1 = new Option(scale.name, scale.id);
      const opt2 = new Option(scale.name, scale.id);
      if (scaleTypeSelect) scaleTypeSelect.add(opt1);
      if (chordScaleSelect) chordScaleSelect.add(opt2);
    });

    if (scaleRootSelect) scaleRootSelect.value = state.selectedRoot;
    if (scaleTypeSelect) scaleTypeSelect.value = state.selectedScale;
    if (chordRootSelect) chordRootSelect.value = state.selectedRoot;
    if (chordScaleSelect) chordScaleSelect.value = state.selectedScale;
  }

  // Sync Selects between Tab 2 and Tab 3
  if (scaleRootSelect) {
    scaleRootSelect.addEventListener('change', (e) => {
      state.selectedRoot = e.target.value;
      if (chordRootSelect) chordRootSelect.value = state.selectedRoot;
      renderTab2();
      renderTab3();
    });
  }

  if (scaleTypeSelect) {
    scaleTypeSelect.addEventListener('change', (e) => {
      state.selectedScale = e.target.value;
      if (chordScaleSelect) chordScaleSelect.value = state.selectedScale;
      renderTab2();
      renderTab3();
    });
  }

  if (chordRootSelect) {
    chordRootSelect.addEventListener('change', (e) => {
      state.selectedRoot = e.target.value;
      if (scaleRootSelect) scaleRootSelect.value = state.selectedRoot;
      renderTab3();
      renderTab2();
    });
  }

  if (chordScaleSelect) {
    chordScaleSelect.addEventListener('change', (e) => {
      state.selectedScale = e.target.value;
      if (scaleTypeSelect) scaleTypeSelect.value = state.selectedScale;
      renderTab3();
      renderTab2();
    });
  }

  // ==========================================
  // --- VEXFLOW STAVE RENDERERS ---
  // ==========================================

  function getVexFlow() {
    if (window.Vex && window.Vex.Flow) {
      return window.Vex.Flow;
    }
    return null;
  }

  /**
   * Render a single note on Treble Clef stave (Tab 1)
   */
  function renderSingleNoteStave(noteInfo) {
    if (!singleStaveContainer) return;
    singleStaveContainer.innerHTML = '';

    const VF = getVexFlow();
    if (!VF) {
      singleStaveContainer.innerHTML = `<div style="padding:20px; color:#BD5338;">خطوط حامل در حال بارگذاری است...</div>`;
      return;
    }

    const containerWidth = Math.min(singleStaveContainer.clientWidth || 320, 480);
    const renderer = new VF.Renderer(singleStaveContainer, VF.Renderer.Backends.SVG);
    renderer.resize(containerWidth, 140);
    const context = renderer.getContext();
    context.setFont('Vazirmatn', 10, '').setBackgroundFillStyle('#FCFAF6');

    // Create Treble Clef Stave
    const stave = new VF.Stave(15, 15, containerWidth - 30);
    stave.addClef('treble');
    stave.setContext(context).draw();

    try {
      // VexFlow key format: e.g. "c#/4", "f/5", "e/3"
      const noteKey = noteInfo.vexKey || 'c/4';
      const staveNote = new VF.StaveNote({
        keys: [noteKey],
        duration: 'w',
        clef: 'treble'
      });

      // Style notehead in terracotta
      staveNote.setStyle({ fillStyle: '#BD5338', strokeStyle: '#BD5338' });

      // Add accidental if needed
      if (noteInfo.accidental) {
        staveNote.addModifier(new VF.Accidental(noteInfo.accidental), 0);
      }

      const voice = new VF.Voice({ num_beats: 4, beat_value: 4 });
      voice.setStrict(false);
      voice.addTickables([staveNote]);

      new VF.Formatter().joinVoices([voice]).format([voice], containerWidth - 90);
      voice.draw(context, stave);
    } catch (err) {
      console.warn('VexFlow render single note error:', err);
    }
  }

  /**
   * Render full ascending scale notes on Treble Clef stave (Tab 2)
   */
  function renderScaleStave(scaleNotes) {
    if (!scaleStaveContainer) return;
    scaleStaveContainer.innerHTML = '';

    const VF = getVexFlow();
    if (!VF) return;

    const containerWidth = Math.min(scaleStaveContainer.clientWidth || 340, 520);
    const renderer = new VF.Renderer(scaleStaveContainer, VF.Renderer.Backends.SVG);
    renderer.resize(containerWidth, 140);
    const context = renderer.getContext();
    context.setFont('Vazirmatn', 9, '').setBackgroundFillStyle('#FCFAF6');

    const stave = new VF.Stave(10, 15, containerWidth - 20);
    stave.addClef('treble');
    stave.setContext(context).draw();

    try {
      // Build notes in written treble octave range (guitar middle C4 - C5)
      let currentOctave = 4;
      let prevPitch = -1;

      const staveNotes = scaleNotes.map((n, idx) => {
        if (prevPitch !== -1 && n.pitchClass <= prevPitch) {
          currentOctave++;
        }
        prevPitch = n.pitchClass;

        const letter = n.letter.toLowerCase();
        const acc = n.accidental || '';
        const key = `${letter}${acc}/${currentOctave}`;

        const sn = new VF.StaveNote({
          keys: [key],
          duration: 'q',
          clef: 'treble'
        });

        if (idx === 0) {
          // Highlight Root note in terracotta
          sn.setStyle({ fillStyle: '#BD5338', strokeStyle: '#BD5338' });
        } else {
          sn.setStyle({ fillStyle: '#28201B', strokeStyle: '#28201B' });
        }

        if (acc) {
          sn.addModifier(new VF.Accidental(acc), 0);
        }

        return sn;
      });

      const voice = new VF.Voice({ num_beats: scaleNotes.length, beat_value: 4 });
      voice.setStrict(false);
      voice.addTickables(staveNotes);

      new VF.Formatter().joinVoices([voice]).format([voice], containerWidth - 85);
      voice.draw(context, stave);
    } catch (err) {
      console.warn('VexFlow scale render error:', err);
    }
  }

  /**
   * Render miniature Triad chord stave (Tab 3)
   */
  function renderTriadStave(containerEl, triad) {
    if (!containerEl) return;
    containerEl.innerHTML = '';

    const VF = getVexFlow();
    if (!VF) return;

    const width = 110;
    const height = 115;
    const renderer = new VF.Renderer(containerEl, VF.Renderer.Backends.SVG);
    renderer.resize(width, height);
    const context = renderer.getContext();
    context.setFont('Vazirmatn', 8, '').setBackgroundFillStyle('#FCFAF6');

    const stave = new VF.Stave(5, 5, width - 10);
    stave.addClef('treble');
    stave.setContext(context).draw();

    try {
      // Determine octaves for stacked 1 - 3 - 5
      let oct1 = 4;
      let oct2 = triad.thirdNote.pitchClass < triad.rootNote.pitchClass ? oct1 + 1 : oct1;
      let oct3 = triad.fifthNote.pitchClass < triad.thirdNote.pitchClass ? oct2 + 1 : oct2;

      const k1 = `${triad.rootNote.letter.toLowerCase()}${triad.rootNote.accidental || ''}/${oct1}`;
      const k2 = `${triad.thirdNote.letter.toLowerCase()}${triad.thirdNote.accidental || ''}/${oct2}`;
      const k3 = `${triad.fifthNote.letter.toLowerCase()}${triad.fifthNote.accidental || ''}/${oct3}`;

      const chordNote = new VF.StaveNote({
        keys: [k1, k2, k3],
        duration: 'w',
        clef: 'treble'
      });

      chordNote.setStyle({ fillStyle: '#28201B', strokeStyle: '#28201B' });

      if (triad.rootNote.accidental) chordNote.addModifier(new VF.Accidental(triad.rootNote.accidental), 0);
      if (triad.thirdNote.accidental) chordNote.addModifier(new VF.Accidental(triad.thirdNote.accidental), 1);
      if (triad.fifthNote.accidental) chordNote.addModifier(new VF.Accidental(triad.fifthNote.accidental), 2);

      const voice = new VF.Voice({ num_beats: 4, beat_value: 4 });
      voice.setStrict(false);
      voice.addTickables([chordNote]);

      new VF.Formatter().joinVoices([voice]).format([voice], width - 40);
      voice.draw(context, stave);
    } catch (err) {
      console.warn('VexFlow triad render error:', err);
    }
  }

  // ==========================================
  // --- TAB 1: NOTES (FRETBOARD NUT 0-4) ---
  // ==========================================

  function renderTab1() {
    renderNutFretboard();
    updateNoteSpotlight(state.selectedNote.stringNumber, state.selectedNote.fretNumber);
  }

  function renderNutFretboard() {
    if (!nutFretboardView) return;
    nutFretboardView.innerHTML = '';

    const container = document.createElement('div');
    container.className = 'fretboard-scrollable';

    const stringsGrid = document.createElement('div');
    stringsGrid.className = 'strings-grid';

    // Fret wire overlay
    const wiresOverlay = document.createElement('div');
    wiresOverlay.className = 'fret-wires-overlay';

    // Fret 0 (Nut)
    const nutCol = document.createElement('div');
    nutCol.className = 'fret-wire-column nut';
    wiresOverlay.appendChild(nutCol);

    // Frets 1 to 4
    for (let f = 1; f <= 4; f++) {
      const col = document.createElement('div');
      col.className = 'fret-wire-column';

      if (f === 3) {
        // Classical guitar 3rd fret marker dot
        const marker = document.createElement('div');
        marker.className = 'fret-marker-dot';
        col.appendChild(marker);
      }

      const label = document.createElement('div');
      label.className = 'fret-number-label';
      label.textContent = `فرت ${f}`;
      col.appendChild(label);

      wiresOverlay.appendChild(col);
    }
    stringsGrid.appendChild(wiresOverlay);

    // Render Strings 1 to 6 (Treble E down to Bass E)
    GUITAR_STRINGS.forEach(str => {
      const strRow = document.createElement('div');
      strRow.className = 'string-row';
      strRow.setAttribute('data-string', str.stringNumber);

      // Frets 0 (Nut open) through 4
      for (let f = 0; f <= 4; f++) {
        const node = document.createElement('div');
        node.className = `fret-node ${f === 0 ? 'nut' : ''}`;
        node.setAttribute('data-string', str.stringNumber);
        node.setAttribute('data-fret', f);

        const fretNote = getGuitarFretNote(str.stringNumber, f);

        const pill = document.createElement('div');
        pill.className = 'fret-pill';
        pill.textContent = f === 0 ? '○' : fretNote.standardName;
        node.appendChild(pill);

        // Highlight currently selected note
        if (state.selectedNote.stringNumber === str.stringNumber && state.selectedNote.fretNumber === f) {
          node.classList.add('active');
        }

        // Click / Touch Handler
        node.addEventListener('pointerdown', (e) => {
          e.preventDefault();
          selectFretNote(str.stringNumber, f);
        });

        strRow.appendChild(node);
      }
      stringsGrid.appendChild(strRow);
    });

    container.appendChild(stringsGrid);
    nutFretboardView.appendChild(container);
  }

  function selectFretNote(stringNumber, fretNumber) {
    state.selectedNote = { stringNumber, fretNumber };

    // Haptic pulse if supported
    if (navigator.vibrate) {
      navigator.vibrate(20);
    }

    const note = getGuitarFretNote(stringNumber, fretNumber);

    // Play classical nylon guitar tone
    guitarSound.playNote(note.frequency);

    // Update UI highlights
    const allNodes = nutFretboardView.querySelectorAll('.fret-node');
    allNodes.forEach(n => {
      const s = parseInt(n.getAttribute('data-string'), 10);
      const f = parseInt(n.getAttribute('data-fret'), 10);
      n.classList.toggle('active', s === stringNumber && f === fretNumber);
    });

    updateNoteSpotlight(stringNumber, fretNumber);

    // Handle quiz validation if active
    if (state.quizActive) {
      validateQuizAnswer(note);
    }
  }

  function updateNoteSpotlight(stringNumber, fretNumber) {
    const note = getGuitarFretNote(stringNumber, fretNumber);

    if (spotlightLetter) spotlightLetter.textContent = note.standardName;
    if (spotlightTitle) spotlightTitle.textContent = `نت ${note.persianName} (${note.standardName})`;
    if (spotlightPersian) spotlightPersian.textContent = `${note.stringName} • اکتاو ${note.writtenOctave}`;
    if (spotlightFret) spotlightFret.textContent = fretNumber === 0 ? 'سیم آزاد' : `فرت ${fretNumber}`;
    if (spotlightFreq) spotlightFreq.textContent = `${note.frequency} Hz`;

    renderSingleNoteStave(note);
  }

  // --- QUIZ FLASHCARD MODE (TAB 1) ---
  if (quizToggleBtn) {
    quizToggleBtn.addEventListener('click', () => {
      state.quizActive = !state.quizActive;
      quizToggleBtn.classList.toggle('active', state.quizActive);
      quizPanel.style.display = state.quizActive ? 'flex' : 'none';
      if (state.quizActive) {
        startNewQuizQuestion();
      }
    });
  }

  function startNewQuizQuestion() {
    // Pick a random string (1-6) and fret (0-4)
    const randomString = Math.floor(Math.random() * 6) + 1;
    const randomFret = Math.floor(Math.random() * 5);
    state.quizTarget = getGuitarFretNote(randomString, randomFret);

    quizInstruction.innerHTML = `نت زیر را روی دسته پیدا کن:<br><strong>«${state.quizTarget.persianName} (${state.quizTarget.standardName})»</strong> روی ${state.quizTarget.stringName}`;
    quizFeedback.style.display = 'none';

    renderSingleNoteStave(state.quizTarget);
  }

  function validateQuizAnswer(selectedNote) {
    if (!state.quizTarget) return;

    if (selectedNote.stringNumber === state.quizTarget.stringNumber && selectedNote.fretNumber === state.quizTarget.fretNumber) {
      state.quizScore++;
      quizScoreEl.textContent = `امتیاز: ${state.quizScore}`;
      quizFeedback.className = 'quiz-feedback success';
      quizFeedback.textContent = 'آفرین! نت صحیح را پیدا کردی 👏';
      quizFeedback.style.display = 'block';

      setTimeout(() => {
        startNewQuizQuestion();
      }, 1200);
    } else {
      quizFeedback.className = 'quiz-feedback retry';
      quizFeedback.textContent = `نادرست؛ این نت ${selectedNote.persianName} است. دوباره تلاش کن!`;
      quizFeedback.style.display = 'block';
    }
  }

  // ==========================================
  // --- TAB 2: SCALES (EXPLORER 0-12) ---
  // ==========================================

  function renderTab2() {
    const scaleNotes = getScaleNotes(state.selectedRoot, state.selectedScale);
    const scaleInfo = SCALES[state.selectedScale] || SCALES.major;

    // Scale description
    if (scaleDescEl) {
      scaleDescEl.textContent = scaleInfo.description;
    }

    // Scale formula chips
    if (scaleFormulaBadge) {
      const stepNames = scaleInfo.steps.map(s => s === 2 ? 'پرده' : s === 1 ? 'نیم‌پرده' : `${s} ن.پ`);
      scaleFormulaBadge.textContent = stepNames.join(' - ');
    }

    // Scale Notes chips row
    renderScaleChips(scaleNotes);

    // Stave rendering
    renderScaleStave(scaleNotes);

    // Full Fretboard (frets 0 to 12)
    renderFullFretboard(scaleNotes);
  }

  function renderScaleChips(scaleNotes) {
    if (!scaleChipsRow) return;
    scaleChipsRow.innerHTML = '';

    scaleNotes.forEach((n, idx) => {
      const chip = document.createElement('div');
      chip.className = `scale-note-chip ${idx === 0 ? 'root-chip' : ''}`;
      chip.setAttribute('data-index', idx);

      const deg = document.createElement('div');
      deg.className = 'chip-degree';
      deg.textContent = n.degreePersian;

      const name = document.createElement('div');
      name.className = 'chip-name';
      name.textContent = n.name;

      chip.appendChild(deg);
      chip.appendChild(name);

      chip.addEventListener('click', () => {
        // Play note frequency based on mid octave
        const midi = 60 + n.semitonesFromRoot;
        const freq = 440 * Math.pow(2, (midi - 69) / 12);
        guitarSound.playNote(freq);
      });

      scaleChipsRow.appendChild(chip);
    });
  }

  function renderFullFretboard(scaleNotes) {
    if (!fullFretboardView) return;
    fullFretboardView.innerHTML = '';

    const container = document.createElement('div');
    container.className = 'fretboard-scrollable';

    const stringsGrid = document.createElement('div');
    stringsGrid.className = 'strings-grid';

    // Fret wires overlay (Frets 0 to 12)
    const wiresOverlay = document.createElement('div');
    wiresOverlay.className = 'fret-wires-overlay';

    // Nut
    const nutCol = document.createElement('div');
    nutCol.className = 'fret-wire-column nut';
    wiresOverlay.appendChild(nutCol);

    // Frets 1 to 12
    for (let f = 1; f <= 12; f++) {
      const col = document.createElement('div');
      col.className = 'fret-wire-column';

      // Position marker dots
      if ([3, 5, 7, 9].includes(f)) {
        const dot = document.createElement('div');
        dot.className = 'fret-marker-dot';
        col.appendChild(dot);
      } else if (f === 12) {
        // 12th fret double dot
        const doubleDot = document.createElement('div');
        doubleDot.className = 'fret-marker-double';
        doubleDot.innerHTML = `<span></span><span></span>`;
        col.appendChild(doubleDot);
      }

      const label = document.createElement('div');
      label.className = 'fret-number-label';
      label.textContent = `${f}`;
      col.appendChild(label);

      wiresOverlay.appendChild(col);
    }
    stringsGrid.appendChild(wiresOverlay);

    const rootPitchClass = scaleNotes[0].pitchClass;
    const scalePitchClasses = new Set(scaleNotes.map(n => n.pitchClass));

    // Render 6 strings
    GUITAR_STRINGS.forEach(str => {
      const strRow = document.createElement('div');
      strRow.className = 'string-row';
      strRow.setAttribute('data-string', str.stringNumber);

      for (let f = 0; f <= 12; f++) {
        const node = document.createElement('div');
        node.className = `fret-node ${f === 0 ? 'nut' : ''}`;
        node.setAttribute('data-string', str.stringNumber);
        node.setAttribute('data-fret', f);

        const fretNote = getGuitarFretNote(str.stringNumber, f);
        const isInScale = scalePitchClasses.has(fretNote.pitchClass);
        const isRoot = fretNote.pitchClass === rootPitchClass;

        if (isInScale) {
          node.classList.add('in-scale');
          if (isRoot) node.classList.add('is-root');

          const matchingScaleNote = scaleNotes.find(sn => sn.pitchClass === fretNote.pitchClass);

          const pill = document.createElement('div');
          pill.className = 'fret-pill';
          pill.textContent = isRoot ? 'R' : (matchingScaleNote ? matchingScaleNote.name : fretNote.standardName);
          node.appendChild(pill);
        } else {
          const pill = document.createElement('div');
          pill.className = 'fret-pill';
          pill.style.opacity = '0.15';
          pill.textContent = '·';
          node.appendChild(pill);
        }

        // Tapping on note
        node.addEventListener('pointerdown', (e) => {
          e.preventDefault();
          guitarSound.playNote(fretNote.frequency);
          if (navigator.vibrate) navigator.vibrate(15);
        });

        strRow.appendChild(node);
      }
      stringsGrid.appendChild(strRow);
    });

    container.appendChild(stringsGrid);
    fullFretboardView.appendChild(container);
  }

  // Play Scale Button
  if (playScaleBtn) {
    playScaleBtn.addEventListener('click', () => {
      if (state.isPlayingScale) return;
      state.isPlayingScale = true;
      playScaleBtn.disabled = true;
      playScaleBtn.innerHTML = `<span>در حال پخش گام...</span>`;

      const scaleNotes = getScaleNotes(state.selectedRoot, state.selectedScale);
      const audioNotes = scaleNotes.map(n => {
        const midi = 60 + n.semitonesFromRoot;
        return {
          frequency: 440 * Math.pow(2, (midi - 69) / 12)
        };
      });

      const chips = scaleChipsRow.querySelectorAll('.scale-note-chip');

      guitarSound.playScale(audioNotes, 115, (idx) => {
        chips.forEach((c, i) => c.classList.toggle('playing', i === idx));
      }, () => {
        chips.forEach(c => c.classList.remove('playing'));
        state.isPlayingScale = false;
        playScaleBtn.disabled = false;
        playScaleBtn.innerHTML = `
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
            <path d="M8 5v14l11-7z"/>
          </svg>
          <span>پخش پیوسته گام</span>
        `;
      });
    });
  }

  // ==========================================
  // --- TAB 3: DIATONIC TRIADS ---
  // ==========================================

  function renderTab3() {
    const result = calculateDiatonicTriads(state.selectedRoot, state.selectedScale);

    if (!result.isSupported) {
      if (triadsContainer) triadsContainer.style.display = 'none';
      if (nonDiatonicNotice) {
        nonDiatonicNotice.style.display = 'flex';
        const msgEl = nonDiatonicNotice.querySelector('.notice-content');
        if (msgEl) msgEl.textContent = result.message;
      }
      return;
    }

    if (nonDiatonicNotice) nonDiatonicNotice.style.display = 'none';
    if (triadsContainer) {
      triadsContainer.style.display = 'flex';
      triadsContainer.innerHTML = '';

      result.triads.forEach(triad => {
        const card = document.createElement('div');
        card.className = 'triad-card';

        // Quality badge class
        const qualityClass = `quality-${triad.quality.toLowerCase()}`;

        card.innerHTML = `
          <div class="triad-header">
            <div class="triad-title-group">
              <div class="roman-pill">${triad.romanNumeral}</div>
              <div class="triad-names">
                <h3>${triad.chordName}</h3>
                <p>${triad.degreePersian}</p>
              </div>
            </div>
            <span class="triad-quality-tag ${qualityClass}">${triad.qualityPersian}</span>
          </div>
          <div class="triad-body">
            <div class="triad-info-box">
              <div class="triad-formula-row">
                <span>نت‌های آکورد:</span>
                <span class="triad-formula-notes">${triad.formula}</span>
              </div>
              <div class="stave-wrapper" style="min-height: 110px; width: 120px;" id="stave-triad-${triad.degreeIndex}">
                <!-- VexFlow Stave inserted dynamically -->
              </div>
              <button class="btn-secondary btn-strum-chord" data-chord="${triad.chordName}">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"/>
                </svg>
                <span>شنیدن آکورد</span>
              </button>
            </div>
            <div class="chord-diagram-container">
              ${renderChordDiagramSVG(triad.chordName, triad)}
            </div>
          </div>
        `;

        // Strum button event
        const strumBtn = card.querySelector('.btn-strum-chord');
        strumBtn.addEventListener('click', () => {
          // Play 3 notes arpeggiated
          const rootFreq = 440 * Math.pow(2, (60 + triad.rootNote.pitchClass - 69) / 12);
          const thirdFreq = 440 * Math.pow(2, (60 + triad.thirdNote.pitchClass - 69) / 12);
          const fifthFreq = 440 * Math.pow(2, (60 + triad.fifthNote.pitchClass - 69) / 12);

          guitarSound.strumChord([
            { frequency: rootFreq },
            { frequency: thirdFreq },
            { frequency: fifthFreq }
          ]);
        });

        triadsContainer.appendChild(card);

        // Render VexFlow stave for this triad
        setTimeout(() => {
          const staveEl = document.getElementById(`stave-triad-${triad.degreeIndex}`);
          renderTriadStave(staveEl, triad);
        }, 10);
      });
    }
  }

  // Window resize handler for VexFlow SVG responsive width
  let resizeTimeout;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimeout);
    resizeTimeout = setTimeout(() => {
      if (state.currentTab === 'tab-notes') {
        renderSingleNoteStave(getGuitarFretNote(state.selectedNote.stringNumber, state.selectedNote.fretNumber));
      } else if (state.currentTab === 'tab-scales') {
        renderScaleStave(getScaleNotes(state.selectedRoot, state.selectedScale));
      }
    }, 150);
  });

  // Initial startup
  populateSelects();
  renderTab1();
});
