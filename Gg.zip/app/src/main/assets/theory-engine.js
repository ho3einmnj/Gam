/**
 * Classical Guitar Music Theory Engine
 * Dynamic interval-based music theory calculations for classical guitarists.
 * Does not hardcode scale notes; dynamically calculates accurate diatonic spellings.
 */

// Natural note letter definitions and their semitone positions (C = 0)
const NATURAL_NOTES = [
  { letter: 'C', semitone: 0 },
  { letter: 'D', semitone: 2 },
  { letter: 'E', semitone: 4 },
  { letter: 'F', semitone: 5 },
  { letter: 'G', semitone: 7 },
  { letter: 'A', semitone: 9 },
  { letter: 'B', semitone: 11 }
];

const PERSIAN_NOTE_NAMES = {
  'C': 'دو',
  'D': 'رِ',
  'E': 'می',
  'F': 'فا',
  'G': 'سل',
  'A': 'لا',
  'B': 'سی'
};

const ACCIDENTAL_PERSIAN = {
  '#': 'دیز',
  '##': 'دوبل دیز',
  'b': 'بمل',
  'bb': 'دوبل بمل',
  '': ''
};

// Available Root Notes for selection
const ROOT_NOTES = [
  { id: 'C',  name: 'C',  persian: 'دو',        letter: 'C', accidental: '' },
  { id: 'C#', name: 'C♯', persian: 'دو دیز',    letter: 'C', accidental: '#' },
  { id: 'D',  name: 'D',  persian: 'رِ',        letter: 'D', accidental: '' },
  { id: 'Eb', name: 'E♭', persian: 'می بمل',   letter: 'E', accidental: 'b' },
  { id: 'E',  name: 'E',  persian: 'می',        letter: 'E', accidental: '' },
  { id: 'F',  name: 'F',  persian: 'فا',        letter: 'F', accidental: '' },
  { id: 'F#', name: 'F♯', persian: 'فا دیز',    letter: 'F', accidental: '#' },
  { id: 'G',  name: 'G',  persian: 'سل',        letter: 'G', accidental: '' },
  { id: 'Ab', name: 'A♭', persian: 'لا بمل',   letter: 'A', accidental: 'b' },
  { id: 'A',  name: 'A',  persian: 'لا',        letter: 'A', accidental: '' },
  { id: 'Bb', name: 'B♭', persian: 'سی بمل',   letter: 'B', accidental: 'b' },
  { id: 'B',  name: 'B',  persian: 'سی',        letter: 'B', accidental: '' }
];

// Scale Definitions: interval steps in semitones
const SCALES = {
  major: {
    id: 'major',
    name: 'ماژور (طبیعی)',
    nameEn: 'Major (Ionian)',
    steps: [2, 2, 1, 2, 2, 2, 1], // W-W-H-W-W-W-H
    isDiatonic: true,
    description: 'گام پایه‌ای موسیقی کلاسیک غربی با فرمول پرده-پرده-نیم‌پرده-پرده-پرده-پرده-نیم‌پرده'
  },
  natural_minor: {
    id: 'natural_minor',
    name: 'مینور تئوریک (طبیعی)',
    nameEn: 'Natural Minor (Aeolian)',
    steps: [2, 1, 2, 2, 1, 2, 2], // W-H-W-W-H-W-W
    isDiatonic: true,
    description: 'گام مینور طبیعی، مبنای اتودها و قطعات دوره باروک و رنسانس'
  },
  harmonic_minor: {
    id: 'harmonic_minor',
    name: 'مینور هارمونیک',
    nameEn: 'Harmonic Minor',
    steps: [2, 1, 2, 2, 1, 3, 1], // W-H-W-W-H-1.5-H (Raised 7th degree leading tone)
    isDiatonic: true,
    description: 'دارای درجه ۷ برآمده (محسوس)؛ بسیار رایج در رپرتوار گیتار اسپانیایی و کلاسیک تارگا و لئو براور'
  },
  melodic_minor: {
    id: 'melodic_minor',
    name: 'مینور ملودیک (بالارونده)',
    nameEn: 'Melodic Minor (Ascending)',
    steps: [2, 1, 2, 2, 2, 2, 1], // W-H-W-W-W-W-H (Raised 6th and 7th degrees)
    isDiatonic: true,
    description: 'درجات ۶ و ۷ نیم‌پرده بالا برده شده‌اند تا فاصله دوم افزوده مینور هارمونیک را ملایم کند'
  },
  major_pentatonic: {
    id: 'major_pentatonic',
    name: 'پنتاتونیک ماژور',
    nameEn: 'Major Pentatonic',
    steps: [2, 2, 3, 2, 3], // 1, 2, 3, 5, 6
    isDiatonic: false,
    degreesFromMajor: [0, 1, 2, 4, 5],
    description: 'گام پنج‌نتی ماژور با حذف درجات ۴ و ۷؛ دارای صدایی لطیف، باز و بدون اصطکاک نیم‌پرده‌ای'
  },
  minor_pentatonic: {
    id: 'minor_pentatonic',
    name: 'پنتاتونیک مینور',
    nameEn: 'Minor Pentatonic',
    steps: [3, 2, 2, 3, 2], // 1, b3, 4, 5, b7
    isDiatonic: false,
    degreesFromMinor: [0, 2, 3, 4, 6],
    description: 'گام پنج‌نتی مینور پرکاربرد در بداهه‌نوازی، قطعات مدرن و الگوهای سرعتی فرتبورد'
  },
  chromatic: {
    id: 'chromatic',
    name: 'کروماتیک',
    nameEn: 'Chromatic',
    steps: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    isDiatonic: false,
    description: 'گام دوازده‌نتی شامل تمام نیم‌پرده‌ها؛ زیربنای اتودهای تکنیک دست چپ و انگشت‌گذاری مستقل'
  }
};

// Classical Guitar 6 Strings Standard Tuning (EADGBE)
// Written octave in classical guitar treble clef notation (one octave above sounding pitch)
const GUITAR_STRINGS = [
  { stringNumber: 1, name: 'می زیر (سیم ۱)', letter: 'E', accidental: '', octave: 5, writtenMidi: 64 + 12, soundingMidi: 64, openPitchClass: 4 },
  { stringNumber: 2, name: 'سی (سیم ۲)',     letter: 'B', accidental: '', octave: 4, writtenMidi: 59 + 12, soundingMidi: 59, openPitchClass: 11 },
  { stringNumber: 3, name: 'سل (سیم ۳)',    letter: 'G', accidental: '', octave: 4, writtenMidi: 55 + 12, soundingMidi: 55, openPitchClass: 7 },
  { stringNumber: 4, name: 'رِ (سیم ۴)',     letter: 'D', accidental: '', octave: 4, writtenMidi: 50 + 12, soundingMidi: 50, openPitchClass: 2 },
  { stringNumber: 5, name: 'لا (سیم ۵)',     letter: 'A', accidental: '', octave: 3, writtenMidi: 45 + 12, soundingMidi: 45, openPitchClass: 9 },
  { stringNumber: 6, name: 'می بم (سیم ۶)',  letter: 'E', accidental: '', octave: 3, writtenMidi: 40 + 12, soundingMidi: 40, openPitchClass: 4 }
];

// Helper: Convert letter + accidental to semitone (0-11)
function noteToPitchClass(letter, accidental = '') {
  const nat = NATURAL_NOTES.find(n => n.letter === letter);
  if (!nat) return 0;
  let semi = nat.semitone;
  if (accidental === '#') semi += 1;
  else if (accidental === '##') semi += 2;
  else if (accidental === 'b') semi -= 1;
  else if (accidental === 'bb') semi -= 2;
  return ((semi % 12) + 12) % 12;
}

// Convert accidental symbol to theoretical offset
function accidentalOffset(acc) {
  if (acc === '#') return 1;
  if (acc === '##') return 2;
  if (acc === 'b') return -1;
  if (acc === 'bb') return -2;
  return 0;
}

function offsetToAccidental(offset) {
  if (offset === 0) return '';
  if (offset === 1) return '#';
  if (offset === 2) return '##';
  if (offset === -1) return 'b';
  if (offset === -2) return 'bb';
  return '';
}

/**
 * Calculates accurate theoretical note spelling for a 7-note diatonic scale.
 * Enforces that each of the 7 letter names appears exactly once in alphabetical order.
 */
function calculateDiatonicScale(rootLetter, rootAccidental, steps) {
  const rootIndex = NATURAL_NOTES.findIndex(n => n.letter === rootLetter);
  const rootPitch = (NATURAL_NOTES[rootIndex].semitone + accidentalOffset(rootAccidental) + 12) % 12;

  const notes = [];
  let currentPitch = rootPitch;

  for (let i = 0; i < 7; i++) {
    const letterIdx = (rootIndex + i) % 7;
    const naturalNote = NATURAL_NOTES[letterIdx];
    const naturalPitch = naturalNote.semitone;

    // Calculate required offset between target pitch and natural letter pitch
    let diff = (currentPitch - naturalPitch) % 12;
    if (diff > 6) diff -= 12;
    if (diff < -6) diff += 12;

    const acc = offsetToAccidental(diff);
    const persianLetter = PERSIAN_NOTE_NAMES[naturalNote.letter];
    const persianAcc = ACCIDENTAL_PERSIAN[acc] || '';
    const persianName = persianAcc ? `${persianLetter} ${persianAcc}` : persianLetter;
    const standardName = naturalNote.letter + (acc === '#' ? '♯' : acc === 'b' ? '♭' : acc);

    notes.push({
      degree: i + 1,
      degreeRoman: ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII'][i],
      degreePersian: ['درجه اول', 'درجه دوم', 'درجه سوم', 'درجه چهارم', 'درجه پنجم', 'درجه ششم', 'درجه هفتم'][i],
      letter: naturalNote.letter,
      accidental: acc,
      name: standardName,
      persianName: persianName,
      pitchClass: (currentPitch % 12 + 12) % 12,
      semitonesFromRoot: (currentPitch - rootPitch + 12) % 12
    });

    currentPitch += steps[i];
  }

  return notes;
}

/**
 * Calculates pentatonic scales derived from the corresponding major/minor diatonic scale
 */
function calculatePentatonicScale(rootLetter, rootAccidental, scaleType) {
  if (scaleType === 'major_pentatonic') {
    const diatonic = calculateDiatonicScale(rootLetter, rootAccidental, SCALES.major.steps);
    // Degrees 1, 2, 3, 5, 6
    const indices = [0, 1, 2, 4, 5];
    return indices.map((idx, pentaIdx) => ({
      ...diatonic[idx],
      degree: pentaIdx + 1,
      degreeRoman: ['I', 'II', 'III', 'IV', 'V'][pentaIdx],
      degreePersian: ['درجه اول', 'درجه دوم', 'درجه سوم', 'درجه چهارم', 'درجه پنجم'][pentaIdx]
    }));
  } else {
    // minor_pentatonic: Degrees 1, b3, 4, 5, b7
    const diatonic = calculateDiatonicScale(rootLetter, rootAccidental, SCALES.natural_minor.steps);
    const indices = [0, 2, 3, 4, 6];
    return indices.map((idx, pentaIdx) => ({
      ...diatonic[idx],
      degree: pentaIdx + 1,
      degreeRoman: ['I', 'II', 'III', 'IV', 'V'][pentaIdx],
      degreePersian: ['درجه اول', 'درجه دوم', 'درجه سوم', 'درجه چهارم', 'درجه پنجم'][pentaIdx]
    }));
  }
}

/**
 * Calculates Chromatic scale ascending from root
 */
function calculateChromaticScale(rootLetter, rootAccidental) {
  const rootPitch = noteToPitchClass(rootLetter, rootAccidental);
  // Standard chromatic chromatic naming preference
  const sharpNames = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
  const flatNames  = ['C', 'Db', 'D', 'Eb', 'E', 'F', 'Gb', 'G', 'Ab', 'A', 'Bb', 'B'];

  const useFlats = ['F', 'Bb', 'Eb', 'Ab'].includes(rootLetter + rootAccidental);
  const nameSet = useFlats ? flatNames : sharpNames;

  const notes = [];
  for (let i = 0; i < 12; i++) {
    const pitch = (rootPitch + i) % 12;
    const n = nameSet[pitch];
    const letter = n[0];
    const acc = n.slice(1);
    const persianLetter = PERSIAN_NOTE_NAMES[letter];
    const persianAcc = ACCIDENTAL_PERSIAN[acc] || '';
    const persianName = persianAcc ? `${persianLetter} ${persianAcc}` : persianLetter;
    const standardName = letter + (acc === '#' ? '♯' : acc === 'b' ? '♭' : '');

    notes.push({
      degree: i + 1,
      degreeRoman: (i + 1).toString(),
      degreePersian: `نیم‌پرده ${i + 1}`,
      letter: letter,
      accidental: acc,
      name: standardName,
      persianName: persianName,
      pitchClass: pitch,
      semitonesFromRoot: i
    });
  }
  return notes;
}

/**
 * Get full scale notes based on root and scale type
 */
function getScaleNotes(rootId, scaleId) {
  const root = ROOT_NOTES.find(r => r.id === rootId) || ROOT_NOTES[0];
  const scale = SCALES[scaleId] || SCALES.major;

  if (scaleId === 'major' || scaleId === 'natural_minor' || scaleId === 'harmonic_minor' || scaleId === 'melodic_minor') {
    return calculateDiatonicScale(root.letter, root.accidental, scale.steps);
  } else if (scaleId === 'major_pentatonic' || scaleId === 'minor_pentatonic') {
    return calculatePentatonicScale(root.letter, root.accidental, scaleId);
  } else if (scaleId === 'chromatic') {
    return calculateChromaticScale(root.letter, root.accidental);
  }
  return calculateDiatonicScale(root.letter, root.accidental, SCALES.major.steps);
}

/**
 * Calculates Diatonic Triads for heptatonic (7-note) scales
 */
function calculateDiatonicTriads(rootId, scaleId) {
  const scale = SCALES[scaleId];
  if (!scale || !scale.isDiatonic) {
    return {
      isSupported: false,
      message: 'گام‌های پنتاتونیک و کروماتیک به دلیل نداشتن ۷ درجه دیاتونیک، آکوردهای سه‌صدایی دیاتونیک سنتی (مبتنی بر فواصل سوم) ندارند. در موسیقی کلاسیک و معاصر (نظیر قطعات لئو براور)، برای این گام‌ها از هارمونی کوارتال (فاصله‌های چهارم) یا بافت‌های چندصدایی کروماتیک بهره می‌گیرند.'
    };
  }

  const scaleNotes = getScaleNotes(rootId, scaleId);
  const classicalRoleNames = [
    { persian: 'تونیک (پایه)', role: 'Tonic' },
    { persian: 'سوپرتونیک (روپایه)', role: 'Supertonic' },
    { persian: 'مدیانت (میانجی)', role: 'Mediant' },
    { persian: 'ساب‌دومینانت (زیرنمایان)', role: 'Subdominant' },
    { persian: 'دومینانت (نمایان)', role: 'Dominant' },
    { persian: 'ساب‌مدیانت (روکاردینال)', role: 'Submediant' },
    { persian: 'لیدینگ‌تون (محسوس)', role: 'Leading Tone' }
  ];

  const triads = [];

  for (let i = 0; i < 7; i++) {
    const rootNote = scaleNotes[i];
    const thirdNote = scaleNotes[(i + 2) % 7];
    const fifthNote = scaleNotes[(i + 4) % 7];

    // Compute intervals in semitones
    const thirdInterval = (thirdNote.pitchClass - rootNote.pitchClass + 12) % 12;
    const fifthInterval = (fifthNote.pitchClass - rootNote.pitchClass + 12) % 12;

    let quality = 'Major';
    let qualityPersian = 'ماژور';
    let symbolSuffix = '';
    let roman = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII'][i];

    if (thirdInterval === 4 && fifthInterval === 7) {
      quality = 'Major';
      qualityPersian = 'ماژور';
      symbolSuffix = '';
      roman = roman.toUpperCase();
    } else if (thirdInterval === 3 && fifthInterval === 7) {
      quality = 'Minor';
      qualityPersian = 'مینور';
      symbolSuffix = 'm';
      roman = roman.toLowerCase();
    } else if (thirdInterval === 3 && fifthInterval === 6) {
      quality = 'Diminished';
      qualityPersian = 'کاسته';
      symbolSuffix = '°';
      roman = roman.toLowerCase() + '°';
    } else if (thirdInterval === 4 && fifthInterval === 8) {
      quality = 'Augmented';
      qualityPersian = 'افزوده';
      symbolSuffix = '+';
      roman = roman.toUpperCase() + '+';
    }

    const chordName = rootNote.name + symbolSuffix;

    triads.push({
      degreeIndex: i + 1,
      degreePersian: `درجه ${['اول', 'دوم', 'سوم', 'چهارم', 'پنجم', 'ششم', 'هفتم'][i]} (${classicalRoleNames[i].persian})`,
      roleName: classicalRoleNames[i].persian,
      roleEn: classicalRoleNames[i].role,
      romanNumeral: roman,
      chordName: chordName,
      quality: quality,
      qualityPersian: qualityPersian,
      rootNote: rootNote,
      thirdNote: thirdNote,
      fifthNote: fifthNote,
      formula: `${rootNote.name} - ${thirdNote.name} - ${fifthNote.name}`
    });
  }

  return {
    isSupported: true,
    triads: triads
  };
}

/**
 * Classical Guitar Fretboard Notes Generator
 * Calculates the exact note, octave, and frequency for string (1-6) and fret (0-19)
 */
function getGuitarFretNote(stringNumber, fretNumber) {
  const stringInfo = GUITAR_STRINGS.find(s => s.stringNumber === stringNumber) || GUITAR_STRINGS[0];
  const soundingMidi = stringInfo.soundingMidi + fretNumber;
  const writtenMidi = stringInfo.writtenMidi + fretNumber; // Classical guitar written 8va in treble clef

  const pitchClass = (stringInfo.openPitchClass + fretNumber) % 12;
  const frequency = 440 * Math.pow(2, (soundingMidi - 69) / 12);

  // Written octave in treble clef
  const writtenOctave = Math.floor(writtenMidi / 12) - 1;
  const soundingOctave = Math.floor(soundingMidi / 12) - 1;

  // Best spelling preference for chromatic frets
  const naturalNotes = ['C', 'C#', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B'];
  const noteName = naturalNotes[pitchClass];
  const letter = noteName[0];
  const accidental = noteName.slice(1);
  const persianLetter = PERSIAN_NOTE_NAMES[letter];
  const persianAcc = ACCIDENTAL_PERSIAN[accidental] || '';
  const persianName = persianAcc ? `${persianLetter} ${persianAcc}` : persianLetter;

  return {
    stringNumber,
    stringName: stringInfo.name,
    fretNumber,
    pitchClass,
    letter,
    accidental,
    writtenOctave,
    soundingOctave,
    writtenMidi,
    soundingMidi,
    frequency: Math.round(frequency * 10) / 10,
    name: noteName,
    standardName: letter + (accidental === '#' ? '♯' : accidental === 'b' ? '♭' : ''),
    persianName: persianName,
    vexKey: `${letter.toLowerCase()}${accidental ? (accidental === '#' ? '#' : 'b') : ''}/${writtenOctave}`
  };
}

// Export for browser or node
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    ROOT_NOTES,
    SCALES,
    GUITAR_STRINGS,
    getScaleNotes,
    calculateDiatonicTriads,
    getGuitarFretNote,
    noteToPitchClass
  };
}
