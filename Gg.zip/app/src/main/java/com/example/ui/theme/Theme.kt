package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = TerracottaPrimary,
    secondary = WarmAmberSecondary,
    tertiary = RosewoodTertiary,
    background = DarkFretboardBg,
    surface = DarkFretboardSurface,
    onPrimary = OnTerracotta,
    onBackground = OnTerracotta,
    onSurface = OnTerracotta
  )

private val LightColorScheme =
  lightColorScheme(
    primary = TerracottaPrimary,
    secondary = WarmAmberSecondary,
    tertiary = RosewoodTertiary,
    background = WarmBackground,
    surface = WarmSurface,
    onPrimary = OnTerracotta,
    onBackground = OnWarmSurface,
    onSurface = OnWarmSurface
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Keep warm guitar aesthetic intentional
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
