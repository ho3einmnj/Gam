package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val TerracottaPrimary = Color(0xFFBD5338)
val WarmAmberSecondary = Color(0xFFC97732)
val RosewoodTertiary = Color(0xFF4A3528)

val WarmBackground = Color(0xFFF7F4EC)
val WarmSurface = Color(0xFFEFE9DE)
val OnWarmSurface = Color(0xFF28201B)
val OnTerracotta = Color(0xFFFAF7F2)

val DarkFretboardBg = Color(0xFF1E1612)
val DarkFretboardSurface = Color(0xFF2B201A)
